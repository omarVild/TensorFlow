import os
from flask import Flask,render_template, request,json
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
import random

app = Flask(__name__)

#http://www.connellybarnes.com/work/class/2016/deep_learning_graphics/proj1/
ticTacToeDataSet =  pd.read_csv('tictac_single.csv', sep =',')
colnames = ['x0','x1','x2','x3','x4','x5','x6','x7','x8']
targets = ['y']

x_train, x_test, y_train, y_test = train_test_split(ticTacToeDataSet[colnames], ticTacToeDataSet[targets], test_size=0.2)


mlp = MLPClassifier(hidden_layer_sizes=(100,100,50),  max_iter=2000, activation= 'relu', learning_rate_init=0.001)
mlp.fit(x_train, y_train.values.ravel())

predicted_values = mlp.predict(x_test)
accuracy= accuracy_score(y_test, predicted_values)
print("accuracy:", accuracy)



@app.route('/')
def hello():
    return 'Welcome to Python Flask!'

@app.route('/ticTac')
def signUp():
    return render_template('ticTac.html')

@app.route('/ticTacMove', methods=['POST'])
def signUpUser():
    data = request.form['ticTacVal']
    data = data[0:17]
    print(data)
    data = data.split(',')
    print([data])
    
    # pass in array and columns
    dataTic = pd.DataFrame(data, columns=colnames)
    predicted_value = mlp.predict([dataTic])
    print(dataTic)

    print("TicTacToe values:\n", dataTic)
    print("predicted_value:", predicted_value)
    
    #return json.dumps({'status':'OK','ticTacResponse':data})
    return str(predicted_value)
if __name__=="__main__":
    app.run()
    
    
